lst1=eval(input("请输入一个列表："))
a=eval(input("第一个下标"))
b=eval(input("第二个下标"))
lst2=lst1[a:b+1:1]
print(lst2)