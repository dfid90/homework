def count_chars(s):
    daxie = 0
    xiaoxie = 0
    shuzi = 0
    other = 0
    for char in s:
        if char.isupper():
            daxie += 1
        elif char.islower():
            xiaoxie += 1
        elif char.isdigit():
            shuzi += 1
        else:
            other += 1
    return (daxie,xiaoxie,shuzi,other)
