a=eval(input("1到8的数字a:"))
b=eval(input("所计算的次数b:"))
#方法一
c=a**b
print(c)
#方法二
d=1
for i in range(1,b+1):
    d*=a
print(d)