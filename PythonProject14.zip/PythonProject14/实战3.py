import random
lst1=[random.randint(1,1000)for _ in range(20)]
lst2=sorted(lst1[0:10:1])
lst3=sorted(lst1[10:20:1],reverse=True)
lst4=lst2+lst3
print(lst4)