for i in range(1,3):
    print(i)
for i in range(3,1000):
    a=True
    for j in range(2,i):
        if(i%j==0):
            a=False
            break
    if a:print(i)


